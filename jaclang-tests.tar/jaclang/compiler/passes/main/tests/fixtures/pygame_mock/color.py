class Color:
    def __init__(self, value: int | str) -> None:
        pass
