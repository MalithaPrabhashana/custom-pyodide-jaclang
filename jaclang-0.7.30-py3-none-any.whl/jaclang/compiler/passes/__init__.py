"""Passes for Jac."""

from .ir_pass import Pass

__all__ = ["Pass"]
